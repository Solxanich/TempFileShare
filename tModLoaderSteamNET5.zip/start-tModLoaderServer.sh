dotnet tModLoaderServer.dll -config serverconfig.txt
