dotnet tModLoaderServer.dll -steam -lobby friends -config serverconfig.txt
